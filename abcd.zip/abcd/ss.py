from tensorflow.keras.preprocessing.image import img_to_array
from tensorflow.keras.models import load_model
import numpy as np 
import pickle
import time
import cv2
import os

model = load_model("C:/Users/Administrator/Desktop/caffemodel/liveness.model")
le = pickle.loads(open("C:/Users/Administrator/Desktop/caffemodel/le.pickle", "rb").read())

protoPath = "C:/Users/Administrator/Desktop/caffemodel/deploy.prototxt"
modelPath ="C:/Users/Administrator/Desktop/caffemodel/ifw-a_final.caffemodel"
net = cv2.dnn.readNetFromCaffe(protoPath, modelPath)
img_path="C:/Users/Administrator/Desktop/caffemodel/nn.jpg"
frame=cv2.imread(img_path)
(h, w) = frame.shape[:2]
blob = cv2.dnn.blobFromImage(cv2.resize(frame, (300, 300)), 1.0,(300, 300), (104.0, 177.0, 123.0))
	# pass the blob through the network and obtain the detections and
	# predictions
net.setInput(blob)
detections = net.forward()

for i in range(0, detections.shape[2]):

    confidence = detections[0, 0, i, 2]
    if confidence >0.3:
        box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
        (startX, startY, endX, endY) = box.astype("int")
        startX = max(0, startX)
        startY = max(0, startY)
        endX = min(w, endX)
        endY = min(h, endY)
        face = frame[startY:endY, startX:endX]
        face = cv2.resize(face, (32, 32))
        face = face.astype("float") / 255.0
        face = img_to_array(face)
        face = np.expand_dims(face, axis=0)
        preds = model.predict(face)[0]
        j = np.argmax(preds)
        label = le.classes_[j]

print(label.decode('UTF-8'))
